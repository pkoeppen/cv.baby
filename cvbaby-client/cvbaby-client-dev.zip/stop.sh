#!/bin/bash
sudo pm2 stop all
sudo rm -rf /var/www/*
sudo rm -rf /var/www/.nuxt
