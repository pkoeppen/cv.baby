#!/bin/bash
sudo nginx -s reload
sudo pm2 restart all
