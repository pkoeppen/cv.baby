importScripts('/_nuxt/workbox.4c4f5ca6.js')

workbox.precaching.precacheAndRoute([
  {
    "url": "/_nuxt/0c378ecb035225d13774.js",
    "revision": "a895a4fbd6336eb68fdfb5e583b047ec"
  },
  {
    "url": "/_nuxt/1a297e91559fbebf4e9b.js",
    "revision": "cbd22ca2395728e62bb2b136597bd8c4"
  },
  {
    "url": "/_nuxt/1bd9135d0399c9ae8303.js",
    "revision": "fa48734dd9c1b53ac7db51dedbf6a234"
  },
  {
    "url": "/_nuxt/2603382c2d002b632589.js",
    "revision": "59a38c6f960a108a2f362f801ed62767"
  },
  {
    "url": "/_nuxt/323ba729593d513157d4.js",
    "revision": "4ce6d7194c625386d533d5adfdc477b7"
  },
  {
    "url": "/_nuxt/349c907d9dfd7e955fa6.js",
    "revision": "2efdd45767a5efa4c65e899e7b2a5cb5"
  },
  {
    "url": "/_nuxt/3e92b964c33e6c6c6af3.js",
    "revision": "1bd17d85215ca20410fedb1d36ea560d"
  },
  {
    "url": "/_nuxt/50ca5a8acc58189ab11e.js",
    "revision": "31d8c4e989399224c092af77117bb0de"
  },
  {
    "url": "/_nuxt/59158f4c40a70e87aa94.js",
    "revision": "56abca9803ade790ae6b5d0382584623"
  },
  {
    "url": "/_nuxt/6953ce48b483da9c207e.js",
    "revision": "a6b709aaa93005f1de9d1448f5682f95"
  },
  {
    "url": "/_nuxt/760f6da621376b738f73.js",
    "revision": "f9f5424c679326ae46fcb6b26d6601f2"
  },
  {
    "url": "/_nuxt/881220673406c56d51d8.js",
    "revision": "8d0daa9b6c924e571453c629a42c2549"
  },
  {
    "url": "/_nuxt/b13ec754d622a0b5bed1.js",
    "revision": "60b9e69c43471dfc3d8ebde6afd7fa54"
  },
  {
    "url": "/_nuxt/d2b30881d30a9458e1d2.js",
    "revision": "64fde93366bdc68fbafa97d4d647dbfe"
  },
  {
    "url": "/_nuxt/dc22ad353facdcea5fcc.js",
    "revision": "ba0459ff019207b3c59d98bf2d530bf2"
  },
  {
    "url": "/_nuxt/e13e55c88ed474866ac7.js",
    "revision": "7c7768c615c7a8e49a5a5b5221a15e9c"
  }
], {
  "cacheId": "cv.baby",
  "directoryIndex": "/",
  "cleanUrls": false
})

workbox.clientsClaim()
workbox.skipWaiting()

workbox.routing.registerRoute(new RegExp('/_nuxt/.*'), workbox.strategies.cacheFirst({}), 'GET')

workbox.routing.registerRoute(new RegExp('/.*'), workbox.strategies.networkFirst({}), 'GET')
