importScripts('/_nuxt/workbox.4c4f5ca6.js')

workbox.precaching.precacheAndRoute([
  {
    "url": "/_nuxt/078d444ce4be15c6db9a.js",
    "revision": "558971c87735cad633636fc7a52c9d90"
  },
  {
    "url": "/_nuxt/2accc7a8eb02f45af0ec.js",
    "revision": "67f62a407b45363939a2b9078841e224"
  },
  {
    "url": "/_nuxt/2c42469846ba8b2a0674.js",
    "revision": "cee2c9b97cf9b20eead5039c4ec55a7a"
  },
  {
    "url": "/_nuxt/3e853468df07a4b1fc55.js",
    "revision": "bfb10abbbd594c28a44c0cad735b1a1d"
  },
  {
    "url": "/_nuxt/4997ae8e1c0002716f55.js",
    "revision": "942e43c1c7139a81d3de82559b2661b2"
  },
  {
    "url": "/_nuxt/610f2fe615477771cb95.js",
    "revision": "3c95f797b68f107b3a9586349da4387e"
  },
  {
    "url": "/_nuxt/689147349bcc75f8c7f3.js",
    "revision": "4e4b61d09c61d1b50456eab120257352"
  },
  {
    "url": "/_nuxt/6953ce48b483da9c207e.js",
    "revision": "a6b709aaa93005f1de9d1448f5682f95"
  },
  {
    "url": "/_nuxt/760f6da621376b738f73.js",
    "revision": "f9f5424c679326ae46fcb6b26d6601f2"
  },
  {
    "url": "/_nuxt/a812e651c2da411a9872.js",
    "revision": "7476a6400b0f78c85714ecd7f4c74433"
  },
  {
    "url": "/_nuxt/b4fecac8ada79775a980.js",
    "revision": "e4520b4ea2279d6009eea21fbefafd1a"
  },
  {
    "url": "/_nuxt/c0b12191df9dd6069c92.js",
    "revision": "f32262bc5d9a5a776b3688b73c94ec81"
  },
  {
    "url": "/_nuxt/c2bf143e2127c025fc32.js",
    "revision": "29389da56463ec6fc09d9027564e7d83"
  },
  {
    "url": "/_nuxt/c721c88c25a1eb13c7c0.js",
    "revision": "709eb19052d50b7b062673d0b6f1a9c8"
  },
  {
    "url": "/_nuxt/c757ccb16a08a93fa1ed.js",
    "revision": "4b70caa2bb1dfce2d02eddad1e3f6f5d"
  },
  {
    "url": "/_nuxt/fe5f553af0648e1ab1d1.js",
    "revision": "0991334271c2ac51eb7efe99b2d210fa"
  }
], {
  "cacheId": "cv.baby",
  "directoryIndex": "/",
  "cleanUrls": false
})

workbox.clientsClaim()
workbox.skipWaiting()

workbox.routing.registerRoute(new RegExp('/_nuxt/.*'), workbox.strategies.cacheFirst({}), 'GET')

workbox.routing.registerRoute(new RegExp('/.*'), workbox.strategies.networkFirst({}), 'GET')
