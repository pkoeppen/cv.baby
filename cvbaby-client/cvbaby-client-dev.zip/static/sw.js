importScripts('/_nuxt/workbox.4c4f5ca6.js')

workbox.precaching.precacheAndRoute([
  {
    "url": "/_nuxt/0045fed4f3c30468e1e5.js",
    "revision": "1437b8b81455829e978e4be3766dd423"
  },
  {
    "url": "/_nuxt/03415b3c19805fc3953b.js",
    "revision": "5e346a3b80ded289b98756858f1cc277"
  },
  {
    "url": "/_nuxt/37897d2fd36474882f49.js",
    "revision": "af9e2f23c3dc50e8d2ba9a203c5871f1"
  },
  {
    "url": "/_nuxt/3b03aecba004cfedf7cd.js",
    "revision": "737e3de782434eff5c4f15f21dd1b500"
  },
  {
    "url": "/_nuxt/3e9b30991f37c60e19b7.js",
    "revision": "9700542f0cdb6b21bf5ff652b1c45fdb"
  },
  {
    "url": "/_nuxt/48f961831c9514a67b5f.js",
    "revision": "fe299eae003d2cea74d50e27c8b983db"
  },
  {
    "url": "/_nuxt/6c39b8bbc857c29a2f1b.js",
    "revision": "2472b70b2fe145f032beaa8db30ce5e6"
  },
  {
    "url": "/_nuxt/88a21f3fd5c29dae16ba.js",
    "revision": "907cb4496257ea19ee150938a9617259"
  },
  {
    "url": "/_nuxt/99fa43e1ae7f274e2690.js",
    "revision": "47e22287c5a1e8827e4ef8b0e6abfece"
  },
  {
    "url": "/_nuxt/a4ca8aaa9b7abe09e983.js",
    "revision": "ce8d47f84956c7de43713da307de86c2"
  },
  {
    "url": "/_nuxt/b06e33b981c928eb5bca.js",
    "revision": "fdfb7c1e5638aaa7c2e27a4b1ab35ed3"
  },
  {
    "url": "/_nuxt/b3addb7727401ecc9258.js",
    "revision": "c7840eb7e74f4546d21ff0bcdb9e4c63"
  },
  {
    "url": "/_nuxt/bde35c92b678f4851bb8.js",
    "revision": "075764df175954444c4dc7a97eb93782"
  },
  {
    "url": "/_nuxt/c1a05e87956c7904840d.js",
    "revision": "650c6fa6318a2da61ee368215eea16a2"
  },
  {
    "url": "/_nuxt/c6399a495a909dc7fd78.js",
    "revision": "a1009cc8672c6ceb98c1b5094ec61a2f"
  },
  {
    "url": "/_nuxt/dcf2294336cf8b8340a1.js",
    "revision": "c40a4bccc690cd47552bebf3e6c8cdee"
  },
  {
    "url": "/_nuxt/e07ae888e17cfd500aed.js",
    "revision": "916686eb04fcaba44c9e5b3797337e40"
  },
  {
    "url": "/_nuxt/e7614081101f05960454.js",
    "revision": "7dbd24f4bf24abd3531a901e72c1b3d6"
  },
  {
    "url": "/_nuxt/f5184930801c71226552.js",
    "revision": "10d7b863ffc449cadb71bf5982dbb44d"
  }
], {
  "cacheId": "cv.baby",
  "directoryIndex": "/",
  "cleanUrls": false
})

workbox.clientsClaim()
workbox.skipWaiting()

workbox.routing.registerRoute(new RegExp('/_nuxt/.*'), workbox.strategies.cacheFirst({}), 'GET')

workbox.routing.registerRoute(new RegExp('/.*'), workbox.strategies.networkFirst({}), 'GET')
