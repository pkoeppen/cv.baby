importScripts('/_nuxt/workbox.4c4f5ca6.js')

workbox.precaching.precacheAndRoute([
  {
    "url": "/_nuxt/0775efd657f9ee8df779.js",
    "revision": "645c3cde3dc260aecb4d965b5a04284e"
  },
  {
    "url": "/_nuxt/0eb716429e8c387cbf56.js",
    "revision": "d5eaec36d87b5d26090c7bed78f43749"
  },
  {
    "url": "/_nuxt/147151c18a4232ac0f29.js",
    "revision": "88048d1f0f23d16b673885c16312e799"
  },
  {
    "url": "/_nuxt/193664680c2a9e2a4750.js",
    "revision": "a732409004837c84e600ffeaa6499808"
  },
  {
    "url": "/_nuxt/3feaa579a95c1c294fe2.js",
    "revision": "ab62db090629dcbdf6d14ce5e5971bf2"
  },
  {
    "url": "/_nuxt/7596f68b9f48975ff28e.js",
    "revision": "833bed5eb8394862af636fc157d99e68"
  },
  {
    "url": "/_nuxt/8553fa11a02cc7e876a0.js",
    "revision": "eaea0860a151c374e464f1fcbb78f829"
  },
  {
    "url": "/_nuxt/90d01b8537c994bda12d.js",
    "revision": "69b1590a42b776391d479fe4d6c8399d"
  },
  {
    "url": "/_nuxt/b655426753402ec59a5b.js",
    "revision": "0a27f9c7ab62c96b562289df417c1215"
  },
  {
    "url": "/_nuxt/c29830b8e50e6540b33c.js",
    "revision": "370e9b81c3972d71eff1de2eef22f242"
  },
  {
    "url": "/_nuxt/cbf645b4e8d7c724ffe4.js",
    "revision": "0d70cedcd89e734539878cac7dcd063a"
  },
  {
    "url": "/_nuxt/cda5f200b0055c652de5.js",
    "revision": "617f14a87cf6373c2e02752c6d5201da"
  },
  {
    "url": "/_nuxt/dd4150f9a1e5b42886c6.js",
    "revision": "19a7326900143a86ba750ff06d3a4379"
  },
  {
    "url": "/_nuxt/f4e616fecb710ce2ce22.js",
    "revision": "0c1aa9a8612470e3367e739d1eea8b0b"
  },
  {
    "url": "/_nuxt/f96e865a679813395fd2.js",
    "revision": "e9eb890ac0a0aa0898c6bbc2b7da36a4"
  },
  {
    "url": "/_nuxt/fb93a313508e6c46239b.js",
    "revision": "ed39c790cdc07e040fa40cb80fe73630"
  },
  {
    "url": "/_nuxt/ff8509e537797007675e.js",
    "revision": "f66d0696ede7e9fad2e99db3ae99bacc"
  }
], {
  "cacheId": "cv.baby",
  "directoryIndex": "/",
  "cleanUrls": false
})

workbox.clientsClaim()
workbox.skipWaiting()

workbox.routing.registerRoute(new RegExp('/_nuxt/.*'), workbox.strategies.cacheFirst({}), 'GET')

workbox.routing.registerRoute(new RegExp('/.*'), workbox.strategies.networkFirst({}), 'GET')
