#!/bin/bash
cd /var/www/
sudo mv -f nginx.conf /etc/nginx/nginx.conf
sudo npm install
